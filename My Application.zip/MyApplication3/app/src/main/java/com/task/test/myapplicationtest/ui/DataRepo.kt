package com.task.test.myapplicationtest.ui

import androidx.lifecycle.MutableLiveData
import com.task.test.myapplicationtest.api.Api

class DataRepo(var apiService: Api) {
    init {
        apiService = Api.create()
    }


    public fun getCompanies(): MutableLiveData<Unit> {
        val call = apiService.getCompanies()

    }

}