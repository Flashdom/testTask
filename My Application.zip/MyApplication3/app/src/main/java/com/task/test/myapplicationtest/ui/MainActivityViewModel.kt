package com.task.test.myapplicationtest.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.task.test.myapplicationtest.api.Companies

class MainActivityViewModel : ViewModel() {
    private val companies: MutableLiveData<List<Companies>> by lazy {
        MutableLiveData().also {
            loadCompanies()
        }
    }

    fun getCompanies(): LiveData<List<Companies>> {
        return companies
    }

    private fun loadCompanies() {
        // Do an asynchronous operation to fetch users.
    }

}