package com.task.test.myapplicationtest.api

data class Companies(val name: String, val number: String, val pictureString :String)